Start the server first before starting the client.
Once the server starts (the last message should be "Processing queues every 2 seconds..."), you can
launch as many clients as you want

To connect to a remote machine, you can change the IP in
"Start Client.bat" to the IP of the remote machine.