# Project Ghost

## Launching
Before launching, make sure you have the latest Java installed (http://java.com/download).
Then, simply double click the file `Project Ghost.jar`. 

You can also run `run.bat` if you are on Windows. This file simply runs the command `java -jar “Project Ghost.jar”`

## Release Notes

This build has a lot of unfinished elements, but the core gameplay should be stable.

You can choose any username, this demo is running in 'offline' mode, meaning no user validation is done. This is for eaiser testing.

It has been observed that some anti-virus programs block internet access for the game. The game accesses the test server located @ 107.170.23.29

WIP Items:
* Items don't have proper icons and are unclear 
* There is no proper HUD 
* Particle effects need to be redone 
* Lighting system needs some work 
* Sprite sorting 
* Menu UI/UX needs to be redone 
* New login system needs to be implemented
